

old_dir = pwd;

cd('/Users/davestanley/Nex/PhD/Skew/Matlab/brian');
currdir = pwd;

path(path, currdir);


cd (old_dir);