

function [dtemp]= readbin(fname, dat_type, pos, len, skip)
% pos - Position in array to seek to
% len - Number of data points to read in
% (Neither of these are in bytes!)

if (~exist('skip','var')); skip=0; end

if strcmp(dat_type,'uint32')
    sizeof_data = 4;
elseif strcmp(dat_type,'float')
    sizeof_data = 4;
elseif strcmp(dat_type,'double')
    sizeof_data = 8;
elseif strcmp(dat_type,'int16')
    sizeof_data = 2;
else
    fprintf('Unknown data type \n');
    return
end


fid = fopen(fname,'rb');
if (fid ~= -1)
       fseek (fid, sizeof_data*pos, 'bof');    %Seeks in bytes
       dtemp = fread(fid,len,dat_type,skip*sizeof_data);

       dtemp = dtemp(:);
       fclose(fid);
   else
        fprintf (['Data file ' fname ' not found! Assume missing and continuing. \n'])
        dtemp = [];
end
   
end