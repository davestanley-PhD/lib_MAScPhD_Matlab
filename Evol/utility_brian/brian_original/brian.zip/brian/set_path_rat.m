


currdir = pwd;

path(path, currdir);

