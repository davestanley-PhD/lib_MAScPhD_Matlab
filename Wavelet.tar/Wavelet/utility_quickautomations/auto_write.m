

eval (['s = ' name ';']);
writedata (s, name, 'stats.txt', fid1, 1);
writedata (s, name, 'betas.txt', fid2, 2);
writedata (s, name, 'power.txt', fid3, 3);
writedata (s, name, 'freq.txt', fid4, 4);
