
set(gcf,'Color',[1,1,1]);