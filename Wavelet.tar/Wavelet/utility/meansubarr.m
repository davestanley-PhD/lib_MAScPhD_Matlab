
function s = meansubarr (s)


    s(:,2) = s(:,2) - mean(s(:,2));            

end